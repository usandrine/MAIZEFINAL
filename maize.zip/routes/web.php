<?php

use Illuminate\Support\Facades\Route;

Route::get('/', fn () => ['message' => 'Maize Yield Tool API']);

