<?php echo e($slot); ?>

<?php /**PATH D:\ALL-GITHUB\smartrest-aiot-backend\vendor\laravel\framework\src\Illuminate\Mail/resources/views/text/footer.blade.php ENDPATH**/ ?>